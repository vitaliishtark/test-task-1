import { useRef } from "react";
import { CodeGenerateButton } from "./components/CodeGenerateButton";
import { InputForCode } from "./components/InputForCode";
import { NoteField } from "./components/NoteField";
import { RadioButton } from "./components/RadioButton";

function App() {
  const radioRef = useRef<HTMLInputElement>(null);

  return (
    <div className="w-screen h-screen bg-white flex items-center justify-center">
      <div className="flex flex-col items-center bg-black h-2/3 sm:w-2/3 sm:h-2/3 lg:w-1/3 md:w-1/2 lg:h-1/2 md:h-2/3 p-6 justify-between rounded-sm gap-2">
        <div className="flex gap-5">
          <RadioButton name={"Options"} label={"Option A"} ref={radioRef} />
          <RadioButton name={"Options"} label={"Option B"} ref={radioRef} />
          <RadioButton name={"Options"} label={"Option C"} ref={radioRef} />
        </div>
        <CodeGenerateButton text="Create code" />
        <InputForCode />
        <NoteField />
      </div>
    </div>
  );
}

export default App;
