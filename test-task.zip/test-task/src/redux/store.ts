import { configureStore } from "@reduxjs/toolkit";
import noteInfoReducer from "./slices/noteInfo";
import selectOptionReducer from "./slices/selectedOption";

export const store = configureStore({
  reducer: { selectOption: selectOptionReducer, noteInfo: noteInfoReducer },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
