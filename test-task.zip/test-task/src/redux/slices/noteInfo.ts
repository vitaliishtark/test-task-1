import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";

interface INoteInfoState {
  value: string;
}

const initialState: INoteInfoState = {
  value: "",
};

export const noteInfoSlice = createSlice({
  name: "noteInfop",
  initialState,
  reducers: {
    setNote: (state, action: PayloadAction<string>) => {
      console.log(action.payload);
      state.value = action.payload;
    },
  },
});

export const { setNote } = noteInfoSlice.actions;

export default noteInfoSlice.reducer;
