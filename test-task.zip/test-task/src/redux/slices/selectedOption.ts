import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";

interface ISelectedOptionSliceState {
  value: "Option A" | "Option B" | "Option C";
}

const initialState: ISelectedOptionSliceState = {
  value: "Option A",
};

export const selectedOptionSlice = createSlice({
  name: "selectedOption",
  initialState,
  reducers: {
    setSelectedOption: (state, action: PayloadAction<"Option A" | "Option B" | "Option C">) => {
      console.log(action.payload);
      state.value = action.payload;
    },
  },
});

export const { setSelectedOption } = selectedOptionSlice.actions;

export default selectedOptionSlice.reducer;
