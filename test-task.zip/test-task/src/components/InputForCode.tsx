import {
  ChangeEvent,
  ForwardRefRenderFunction,
  InputHTMLAttributes,
  forwardRef,
  useState,
} from "react";

interface ICodeInput extends InputHTMLAttributes<HTMLInputElement> {
  ref: string;
  inputStyle?: string;
  inputContainerStyle?: string;
  errorText?: string;
  errorTextStyle?: string;
}

const CodeInput: ForwardRefRenderFunction<HTMLInputElement, ICodeInput> = (
  { inputStyle, inputContainerStyle, errorText, errorTextStyle, ...otherProps },
  ref
) => {
  const [error, setError] = useState<string | null>(null);

  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;

    if (value.length > 11) event.target.value = value.slice(0, 11);

    if (value.length === 11) {
      const regex = /^NEWCODE\d{4}$/;
      const isValid = regex.test(value);
      isValid
        ? setError(null)
        : setError(
            errorText ? errorText : "Invalid code. Please enter a code in the format NEWCODE1234."
          );
    } else setError(null);

    if (otherProps.onChange) otherProps.onChange(event);
  };

  return (
    <div className={`w-full flex flex-col items-center ${inputContainerStyle}`}>
      <input
        className={`bg-white text-black p-2 rounded-sm ${inputStyle}`}
        {...otherProps}
        ref={ref}
        maxLength={11}
        onChange={handleChange}
      />
      {error && <div className={`text-center text-red-500 ${errorTextStyle}`}>{error}</div>}
    </div>
  );
};

export const InputForCode = forwardRef(CodeInput);
