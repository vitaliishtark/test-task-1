import { ForwardRefRenderFunction, forwardRef, useState } from "react";

interface ICodeGenerateButton {
  text: string;
  buttonStyle?: string;
  codeStyle?: string;
  containerStyle?: string;
  ref: string;
}

const CodeButton: ForwardRefRenderFunction<HTMLButtonElement, ICodeGenerateButton> = (
  { text, buttonStyle, codeStyle, containerStyle },
  ref
) => {
  const [code, setCode] = useState<string | null>(null);

  //Frankly, I suppose, that it must be manually created code(that's some strange to generate it and )
  const generateCode = () => {
    const newCode = `NEWCODE${Math.floor(1000 + Math.random() * 9000)}`;
    setCode(newCode);
  };

  return (
    <div className={`flex flex-col gap-2 ${containerStyle}`}>
      <button
        className={`bg-white text-black px-8 font-semibold py-1 rounded-sm cursor-pointer ${buttonStyle}`}
        ref={ref}
        onClick={generateCode}
      >
        {text}
      </button>
      {code && (
        <span className={`text-center bg-white text-black rounded-sm ${codeStyle}`}>{code}</span>
      )}
    </div>
  );
};

export const CodeGenerateButton = forwardRef(CodeButton);
