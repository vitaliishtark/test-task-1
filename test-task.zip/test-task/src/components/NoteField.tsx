import {
  ChangeEvent,
  ForwardRefRenderFunction,
  TextareaHTMLAttributes,
  forwardRef,
  useState,
} from "react";
import { useAppDispatch } from "../redux/hooks";
import { setNote } from "../redux/slices/noteInfo";

interface ITextArea extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  ref: string;
  textAreaContainerStyle?: string;
  textAreaStyle?: string;
  buttonStyle?: string;
}

const NoteInput: ForwardRefRenderFunction<HTMLTextAreaElement, ITextArea> = (
  { textAreaContainerStyle, textAreaStyle, buttonStyle, ...otherProps },
  ref
) => {
  const [noteText, setNoteText] = useState<string>();
  const dispatch = useAppDispatch();
  const handleChange = (event: ChangeEvent<HTMLTextAreaElement>) => {
    setNoteText(event.target.value);
    if (otherProps.onChange) {
      otherProps.onChange(event);
    }
  };

  const onClickHandler = () => {
    noteText && dispatch(setNote(noteText));
  };

  return (
    <div
      className={`flex flex-col w-full p-2 rounded-sm gap-2 items-center bg-black ${textAreaContainerStyle}`}
    >
      <textarea
        className={`p-2 max-w-full w-2/3 bg-slate-100 text-black rounded-sm ${textAreaStyle}`}
        {...otherProps}
        ref={ref}
        onChange={handleChange}
      />
      <button
        className={`bg-white text-black px-8 font-semibold py-1 rounded-sm cursor-pointer ${buttonStyle}`}
        onClick={onClickHandler}
      >
        Send
      </button>
    </div>
  );
};

export const NoteField = forwardRef(NoteInput);
