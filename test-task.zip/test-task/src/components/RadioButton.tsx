import { ChangeEvent, ForwardRefRenderFunction, InputHTMLAttributes, forwardRef } from "react";
import { useAppDispatch } from "../redux/hooks";
import { setSelectedOption } from "../redux/slices/selectedOption";

interface IRadioButton extends InputHTMLAttributes<HTMLInputElement> {
  name: string;
  label: "Option A" | "Option B" | "Option C";
  containerStyle?: string;
  textStyle?: string;
  labelStyle?: string;
  inputStyle?: string;
  ref: string;
}

const RadioInput: ForwardRefRenderFunction<HTMLInputElement, IRadioButton> = (
  { name, label, containerStyle, textStyle, inputStyle, labelStyle, ...otherProps },
  ref
) => {
  const dispatch = useAppDispatch();
  const handleSetOption = () => {
    dispatch(setSelectedOption(label));
  };

  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    handleSetOption();
    if (otherProps.onChange) otherProps.onChange(event);
  };

  return (
    <div className={`${containerStyle}`}>
      <label className={`flex gap-2 ${labelStyle}`}>
        <input
          {...otherProps}
          className={` ${inputStyle}`}
          type="radio"
          name={name}
          ref={ref}
          onChange={handleChange}
        />
        <span className={`text-white  ${textStyle}`}>{label}</span>
      </label>
    </div>
  );
};

export const RadioButton = forwardRef(RadioInput);
